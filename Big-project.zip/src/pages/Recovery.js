import React from 'react'

function Recovery() {
  return (
    <div>Recovery</div>
  )
}

export default Recovery