// export const domain = 'http://localhost:8000'
export const domain = 'https://gurjar-xndl7.ondigitalocean.app'
